# 09 実装プロンプト: Docker・運用周りを仕上げる

ローカル開発と最低限の運用を整備してください。

## 追加してほしいもの
- Dockerfile（multi-stageでもよい）
- docker compose:
  - api
  - postgres
  - volume（postgresデータ）
  - volume（rawデータ格納）
- 起動時にマイグレーションを当てる手順（entrypoint or README）

## 監視の入口
- /healthz を使ったヘルスチェック
- ログはJSON推奨（最低でも時刻とレベルは出す）

## ドキュメント
- README に以下を明記
  - セットアップ
  - ingest → parse → API の最短実行手順
  - サンプルコマンド
  - 想定するRawデータ配置
